import React from "react"

const PassengerInfo = () => {
    return (
<h1>PASSENGER</h1>
);
};

export default PassengerInfo;