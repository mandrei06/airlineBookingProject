
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import java.net.MalformedURLException;

public class Main {
    public static void main(String[] args) throws MalformedURLException, InterruptedException {

        System.setProperty("webdriver.chrome.driver", "C:/Users/Petros.Grivas/Downloads/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("http://localhost:3000/");

        WebElement radioOneWay = driver.findElement(By.id("show"));
        WebElement radioRoundTrip = driver.findElement(By.id("hide"));

        //Thread.sleep(2000);

        radioRoundTrip.click();

        Select countryOrigin = new Select (driver.findElement(By.name("originsDropdown")));
        countryOrigin.selectByVisibleText("Athens");

        //Thread.sleep(2000);


        Select countryDestination  = new Select(driver.findElement(By.name("destinationsDropdown")));
        countryDestination.selectByVisibleText("London");

       //Thread.sleep(2000);


        Select dateOfFlight = new Select(driver.findElement(By.name("datesDropdown")));
        dateOfFlight.selectByVisibleText("16/10/2022");

       // Thread.sleep(2000);

        Select dateOfFlightReturning = new Select(driver.findElement(By.name("returnDatesDropdown")));
        dateOfFlightReturning.selectByVisibleText("16/10/2022");

       // Thread.sleep(2000);

        driver.findElement(By.xpath("//input[@id='olderThan9']")).sendKeys(Keys.ARROW_UP);

        Thread.sleep(2000);

        WebElement buttonSaveInfos =driver.findElement(By.id("saveInfo"));

        buttonSaveInfos.click();




        Thread.sleep(2000);

        WebElement firstName = driver.findElement(By.id("fistName"));
        firstName.sendKeys("Sean");
        Thread.sleep(2000);


        WebElement lastName = driver.findElement(By.id("lastName"));
        lastName.sendKeys("IceHole");
        Thread.sleep(2000);

        WebElement nationality = driver.findElement(By.id("nationality"));
        nationality.sendKeys("Irish");
        Thread.sleep(2000);

        WebElement NIF = driver.findElement(By.id("NIF"));
        NIF.sendKeys("SIU4567420");
        Thread.sleep(2000);

        WebElement age = driver.findElement(By.id("age"));
        age.sendKeys("19");
        Thread.sleep(2000);

        WebElement luggageYes = driver.findElement(By.id("yesLuggage"));
        Thread.sleep(2000);

        WebElement luggageNo = driver.findElement(By.id("noLuggage"));
        Thread.sleep(2000);

        luggageYes.click();
        Thread.sleep(2000);

        WebElement buttonConfirmFlights =driver.findElement(By.id("submit"));
        Thread.sleep(2000);

        buttonConfirmFlights.click();
        Thread.sleep(2000);







    }
}